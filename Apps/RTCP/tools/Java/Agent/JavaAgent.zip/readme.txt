Java Agent
----------

Syntax:
Insert into the java application launch command line 
 -javaagent:/path/greenhat.javaagent.jar=/path/registration.xml
e.g.
 java -javaagent:greenhat.javaagent.jar=registration.xml -jar MyApp.jar

You MUST co-locate greenhat.javaagent.linkage.jar with greenhat.javaagent.jar

DO NOT add these jar files to the CLASSPATH, this is handled automatically.

Memory usage when using the java agent is likely to increase, you should 
consider increasing the size of the permgen pool if you see OutOfMemoryErrors.
e.g.
 -XX:MaxPermSize=256M

Be careful what you record. Recording EVERYTHING may cause performance to
degrade dramatically on large codebases, and may result in RIT running out of
memory. Users should where possible record only the packages they are 
interested in.

FAQ
Q:What versions of Java are supported?
A:Java versions 6 & 7 are currently supported.

Q:Can I use this on my App Server?
A:Yes, but with the condition that most application servers have a Java 2
  Security Manager. This will prevent the agent from working, and could cause
  the server to fail to start if not configured correctly. To configure the
  security manager you need to add the following to the policy file:
  
  grant codeBase "file:///...install-path.../agent/*" {
    permission java.security.AllPermission;
  };

  Note: The example 'agent' directory should contain greenhat.javaagent.jar,
  greenhat.javaagent.ext.jar and greenhat.javaagent.linkage.jar.
  
  For IBM WebSphere Application Server the policy file can be found here:
  ${was.install.root}/profiles/${appserver.name}/properties/server.policy
  
Q:Can I stop use of java util logging (JUL)?
A:Yes, JBoss 7 for example needs to explicitly initialize java logging thereby
  conflicting with the java agents use of JUL. To prevent the java agents use
  of logging add both these properties:
  	  -Dgreenhat.logappender.console.stdout=level:info
  	  -Dcom.ibm.rational.proxy.logging=console
  	  
  Alternatively to switch off logging add both these properties:
  	  -Dgreenhat.logappender.none
  	  -Dcom.ibm.rational.proxy.logging=off
  	  
  Additionally, to use the java agent with JBoss you will also need to add this
  property:
  	  -Djboss.modules.system.pkgs="com.ibm.rational.rit.javaagent.linkage"
  
Q:Help, my JBoss server is still failing to start with the GreenHat JavaAgent.
A:Some versions of JBoss 7 (and EAP 6.x) can fail to initialise their own LogManager 
  when the 'javaagent' is specified. To get around this, the JBoss LogManager jar 
  needs to be added to the boot classpath along with the following other parameters.
  (Set the JBoss LogManager to be the Java Util Logging Manager)
  
		-Djava.util.logging.manager=org.jboss.logmanager.LogManager
  
  (Prefix the boot classpath with the JBoss logging manager jar, 
  	NB: The name of this file CHANGES between releases)
	
		-Xbootclasspath/p:$JBOSS_HOME/modules/system/layers/base/org/jboss/logmanager/main/jboss-logmanager-1.5.1.Final-redhat-1.jar

 (Set the JBoss LogManager jar to be system available)

		-Djboss.modules.system.pkgs=org.jboss.logmanager
   
  There is also a logging configuration bug which has been fixed in JBoss EAP 6.1.1 
  and later, this will not work at EAP 6.1.0 and earlier.
  	*** https://bugzilla.redhat.com/show_bug.cgi?id=969530 *** 
  
Q:Can I record or stub constructor calls?
A:No, you can only record and stub method calls.

Q:Why does my Java application pause on startup when the javaagent is setup?
A:It may be waiting for rules on RTCP (when there are none). 
  To not wait set the switch -Dgreenhat.javaagent.waitForRules=-1
  
Switches:
-Dgreenhat.javaagent.waitForRules=10000
 On startup wait 10 seconds for rules from RTCP.
-Dgreenhat.javaagent.dispatchTimeout=60000
 Wait up to 60 seconds for RIT to decide how to process an intercepted message.

Q:Can I exclude packages from ever being instrumented/recorded?
A:Yes, you can either add them into the registration.xml or use a system property:
  	  -Dgreenhat.javaagent.excludes=org.package1:com.package2
  	  
Q:Can I limit instrumentation/recording to a fixed set of packages?
A:Yes, you can either add them into the registration.xml or use a system property:
  	  -Dgreenhat.javaagent.includes=org.package1:com.package2
  	  
Q:My application hangs when I start it using the java agent, what do I do?
A:Assuming there is no useful logging information then there may be a deadlock.
  This can be diagnosed using jstack. Inspection of thread stacks will provide
  candidates of classes to exclude from instrumentation.

For general information on java agents see: 
http://docs.oracle.com/javase/6/docs/api/java/lang/instrument/package-summary.html

Known issues
dev-40654: Unpatched IBM Websphere Application Servers may behave more reliably when
           in debug mode or with JIT disabled. (Solves NPEs seen in application code)
